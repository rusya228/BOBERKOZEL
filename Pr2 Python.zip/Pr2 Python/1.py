while 1:
    try:
        fn : str= input('введите имя файла: ') 
        if len(fn)<=3:
            print('давай еще символов, надо больше 3-х')
            continue
        if not fn.isalpha():
            print('без цифр!')
            continue
        with open(fn + '.txt','w'):
            print("fayl uspeshno sozdan")
            pass
    except:
        print('че то не то')
    
