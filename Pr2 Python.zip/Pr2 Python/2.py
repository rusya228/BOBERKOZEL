from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler
class Handler(FileSystemEventHandler):
    def on_created(self, event):
        filename : str = event.src_path.replace("C:\\Users\\pr-20.102k-br\\Desktop\\pr2 Python\\", "").replace(".txt", "").lower()
        for char in filename:
            if char in "аиоуыэ":
                print(char)
            else:
                print(char.upper())
        print()

observer = Observer()
observer.schedule(Handler(), path="C:\\Users\\pr-20.102k-br\\Desktop\\pr2 Python")
observer.start()
try:
    while 1:
        pass
except KeyboardInterrupt:
    observer.stop()
    print("Handler stoped")

